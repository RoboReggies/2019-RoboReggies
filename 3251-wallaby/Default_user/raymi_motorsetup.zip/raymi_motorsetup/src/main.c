#include <kipr/botball.h>

int main()
{
    printf("Hello World\n");
    return 0;
    enable_servos(0);
        
    set_servo_position(o<,);
    disable_servos(0);
    digital(0);
    analog(0);
    
}
