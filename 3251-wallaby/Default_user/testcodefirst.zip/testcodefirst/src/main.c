#include <kipr/botball.h>

int main(void){
   int N = 0;
    for( N=0; N<12903;N++) {
     printf("victory royale but it is given to you by a robot 12903 times");
        N=0
    ;}
};
