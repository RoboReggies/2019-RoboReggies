#include <kipr/botball.h>

int main()
{
	create_connect();
    printf("starting turn\n");
    create_drive_direct(-20,20);
    printf("pausing\n");
    msleep(20000);
    printf("stopping turn\n");
	create_stop();
	create_disconnect();
	return 0;
}
