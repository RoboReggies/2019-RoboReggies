#include <kipr/botball.h>

int main()
{
    printf("Hello World\n");
    printf("it's a trap! UwU");
    //Not anything but that
    return 0;
}
