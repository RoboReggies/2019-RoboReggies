#include <kipr/botball.h>

int main()
{
    create_connect();
    create_full();
    //shut_down_in(30);
    //printf("Hello World\n");
    int intDirection = 1;
    int intLeftFrontSensor = 0;
    int intRightFrontSensor = 0;
    int intFrontSensorLine = 1500;
    //int intLeftSensor = 0;
   // int intRightSensor = 0;
   // int intSensorLine = 500;

    while(1){
        console_clear();
        intDirection = 1;
        
    	//intLeftSensor = get_create_lcliff_amt();   
    	//printf("LcliffAMT = %d\n",intLeftSensor);
         //intRightSensor = get_create_rcliff_amt();
    	//printf("RcliffAMT = %d\n",get_create_rcliff_amt());
        
        intLeftFrontSensor = get_create_lfcliff_amt();
    	printf("LcFliffAMT = %d\n",get_create_lfcliff_amt()); 
    	intRightFrontSensor = get_create_rfcliff_amt();
    	printf("RcFliffAMT = %d\n",get_create_rfcliff_amt());
        
        if (intLeftFrontSensor < intFrontSensorLine) {
             intDirection = 1;
        }
        else{
            intDirection = 0;
        }    
    
        if (intRightFrontSensor < intFrontSensorLine) {
             intDirection = intDirection + 2;
        }

        printf("Direction = %d\n", intDirection);
        msleep(250);
        switch(intDirection){
            case 0:
        		printf("\nTurn Right\n");
        		break;
        	case 1:
        		printf("\nFowards\n");
                break;
        	case 2:
        		printf("\nTurn Left\n");
        		break;
	        case 3:
        		printf("\nStop\n");
        		break;
        }
    }
    create_stop();
	create_disconnect();
}
