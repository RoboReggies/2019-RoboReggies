#include <kipr/botball.h>

int main()
{
    printf("Im about to connect :)\n");
    create_connect();
    printf("I have connected\n");
    create_drive_direct(150,150);
    msleep(5000);
    printf("ok im stopping and disconnecting\n");
    create_stop();
    create_disconnect();
    return 0;
}
