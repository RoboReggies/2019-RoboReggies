#include <kipr/botball.h>
#include <stdlib.h>
#include <math.h>

int main()
{
	printf("Starting 1\n");
    int intSpeed = 250;// max == ???  min = ???
    int intDrive[]={200,500,2000};
    //int intTurn[3]={900, -900, -900};
    int intLeg = 0;
    create_connect();
    
    
    set_create_distance(0);
    printf("dist = 0\n");
    printf("intSpeed %d\n",  intSpeed);
    if(intDrive[intLeg] > 0)
    {
       printf("intDrive %d, intLeg %d\n", intDrive[intLeg],  intLeg);
       intSpeed = intSpeed * -1;
    }
    printf("intSpeed %d\n",  intSpeed);
    while (abs(get_create_distance()) < abs(intDrive[intLeg]))
    { 
            //intSpeed * -1;
            
           create_drive_straight(intSpeed);
           printf("intSpeed %d, Get_dist %d, intDrive %d \n", intSpeed, (get_create_distance()), (intDrive[intLeg]));
            
                       //intSpeed * -1;
    }
    if(intDrive[intLeg] > 0)
            { 
                intSpeed = intSpeed * -1;
            }

    printf("I end\n");
    create_stop();
    
    //PUT TURN HERE
    
    intLeg++;
    //void create_drive_straight(int speed);
    //while (get_create_distance < drive [count])
    //{
    //    create_drive_straight(int speed);
    //}
    
	//set_create_distance(0);
	//while (get_create_distance() < 1000)
	//{
	//	create_drive_direct(200, 200);
	//}
	create_stop();
	create_disconnect();
return 0;
}