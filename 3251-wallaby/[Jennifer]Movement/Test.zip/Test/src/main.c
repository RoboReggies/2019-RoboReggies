int main()
{
create_connect();
set_create_distance(0);
//printf("woah"/n);
while (get_create_distance() < 1000)
{
    printf("bumble bee/n");
create_drive_direct(200, 200);
}
    printf("Imma stop/n");
create_stop();
create_disconnect();
return 0;
}