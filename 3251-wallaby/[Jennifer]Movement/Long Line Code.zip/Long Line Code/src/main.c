#include <kipr/botball.h>
#include <stdlib.h>

void glts_drive_forward(int intFunSpeed, int intDistance);
void glts_turnspin(int intFunSpeed, int intAngle);

int main()
{   
    wait_for_light(0);
    create_connect();
	//create_stop();
	printf("Starting\n");
    int intSpeed = 250;// max == ???  min = ???
    int intDrive[]={350,2000, -5, -5000};
    int intTurn[]={-80,80};
    
   
    int intDriveCount = 0;
    int intTurnCount = 0;
    
    glts_drive_forward(intSpeed, intDrive[intDriveCount]);
    intDriveCount++;
    glts_turnspin(intSpeed, intTurn[intTurnCount]);
    
      printf("turn 1 -- intTurn[intTurnCount] %d, intTurnCount %d\n", intTurn[intTurnCount],  intTurnCount);
        
    intTurnCount++;
    glts_drive_forward(intSpeed, intDrive[intDriveCount]);
    intDriveCount++;
    glts_drive_forward(intSpeed, intDrive[intDriveCount]);
    intDriveCount++;
    glts_turnspin(intSpeed, intTurn[intTurnCount]);
    
    printf("turn 2 -- intTurn[intTurnCount] %d, intTurnCount %d\n", intTurn[intTurnCount],  intTurnCount);
    
    glts_drive_forward(intSpeed, intDrive[intDriveCount]);
    
    
	//glts_turnspin(intSpeed, 90);
     
    printf("Done\n");
    create_disconnect();
    return 0;
}
//code so the create will drive straight
void glts_drive_forward (int intFunSpeed, int intDistance)
{
    set_create_distance(0);
    if(intDistance > 0)
    {               
    intFunSpeed = intFunSpeed * -1;
    }  
    while (abs(get_create_distance()) < abs(intDistance) && (get_create_rbump()==0))
    {             
    create_drive_straight(intFunSpeed);           
    }
    if(intDistance > 0)
    { 
    intFunSpeed = intFunSpeed * -1;
    }
}   
//Seperation between driving straight and turning function   
    
    void glts_turnspin (int intFunSpeed, int intAngle)
{
    set_create_total_angle(0);
    if(intAngle > 0) //see if the number is positive/greater than zero it will turn clockwise
    {               
   		while ((abs(get_create_total_angle())) < abs(intAngle))
    	{             
    		create_spin_CW(intFunSpeed);           
    	}
    }
        if (intAngle < 0) //see if the number is negative/less than zero it will turn counterclockwise
   	 while ((abs(get_create_total_angle())) < abs(intAngle))
    {             
    create_spin_CCW(intFunSpeed);           
    }
    ao();
    create_stop();
}