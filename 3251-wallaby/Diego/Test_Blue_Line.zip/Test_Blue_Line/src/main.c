#include <kipr/botball.h>

int main()
{
    create_connect();
    while (get_create_rbump() == 0)
    {
        create_drive_direct(200, 200);
    }
    printf("Hello World\n");
    create_stop();
    create_disconnect();
   
    return 0;
}
