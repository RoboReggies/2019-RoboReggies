#include <kipr/botball.h>

int main()
    
{
    create_connect();
	int left = 2;
	int right = 0;
      
	int leftwheel[4] = {100, 50, 200, 0};
	int rightwheel[4] = {100, 0, 200, 50};
	int count=0;
	    while(count<4)
	    { 
			printf("Drive and turn\n");
			motor(left, leftwheel[count]);
			motor(right, rightwheel[count]);
            create_drive_direct(left, right);
			msleep(1000);
		    count++;
		}
    printf("Hello World\n");
    create_stop();
    create_disconnect();
    return 0;
}
