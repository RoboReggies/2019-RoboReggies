#include <kipr/botball.h>

int main()
{
    create_connect();
    int left = 2;
    int right = 0;
    //printf("left wheel");
    int leftwheel[5] = {10, 0, 20, -10, 0, 10};
    //printf("right wheel");
    int rightwheel[5] = {10, 5, 20, -10, 5, 10};
    int count=0;
    	while(count<5)
   			{
    	    	//printf("The answer to counter is %d, left is %d, right %d\n", count, leftwheel[count], rightwheel[court]);
    	    	movement_relative_position(left, leftwheel[court]);
    	    	movement_relative_position(right, rightwheel[count]);
    	    	msleep(1000);
    	    	count++;
   			}
    create_stop();
    create_disconnect();
return 0;
}