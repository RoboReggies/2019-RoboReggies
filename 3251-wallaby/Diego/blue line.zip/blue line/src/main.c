
#include <kipr/botball.h>

int main()
{
    create_connect();
    int left_wheel [3] = (10, 5, 20, 0);
    int right_wheel [3] = (10, 0, 10, 5);
    int count = 0;
    
   		while ( count < 4);
    //    {
    //        mrp (75, left_wheel [count];
    //        mrp (75, left_wheel [count];
    //        count++;
    //    }
                 
    printf("Hello World\n");
    create_stop();
    create_disconnect();
    return 0;
}
