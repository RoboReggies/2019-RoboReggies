#include <kipr/botball.h>

int main()
{
    printf("hey bixby\n");
    create_connect();//connects and disconects from the CreateBot
    
    create_drive_direct(5000,5000);//controls robot speed
    //create_stop(); //stops the motors
  msleep(1000);
    
    
    
    
    
    //motor(0,1000);
    //motor(1,1000);
  
    
    
    return 0;
}
