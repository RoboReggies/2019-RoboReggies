#include <kipr/botball.h>

int main()
{
    printf("Hello World\n");
    
    motor(0,100);
    motor(1,100);
    msleep(1000);
    //move forward certain distance
    
    motor(0,-100);
    motor(1, 100);
    msleep(5000);
    //turn one wheel right/left and the other straight
    
    ao();
    
    return 0;
}
