#include <kipr/botball.h>
int main()
{
    while (digital (0) == 0)
    {
        if (analog(3)>1600)
			{
			    motor(0,-10);
			    motor(3,90);
			}
		else
		    {
		        motor(0,90);
		        motor(3,-10);
		    }
    }
ao();

return 0;
}