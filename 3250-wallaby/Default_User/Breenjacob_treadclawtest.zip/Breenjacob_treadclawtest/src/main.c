
#include <kipr/botball.h>



void claw(int clawdir)
{
	switch (clawdir)
{
        case 0:
            motor(2, 0);
            printf("I am not moving");
            break;
	  case 1:
			motor(2, 100);
            printf("I am going forward");
            break;
	  case 2:
			motor(2, -100);
            printf("I am going backward");
            break;
	  default:
			motor(2, 0);
			printf("%d", clawdir);
            break;
}
}

int iOff=0;
int iFw=1;
int iBw=2;

int main()
{
   int i=1;
    while (i <= 1)
    {  
        if (digital(0) <= 0)
    {
      claw(iFw);
	  printf("\n I am past the digital parameter \n");
    }
    else
    {
        i=0;
        while (i<= 1000)
        {
            claw(iBw);
            i++;
        }
        printf("Went through else statement, exiting");
        return 0;
    }
    }
}

        
