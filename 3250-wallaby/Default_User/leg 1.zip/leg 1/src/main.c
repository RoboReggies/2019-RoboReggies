#include <kipr/botball.h>

int main()
{
   mrp(0, 5, 1000); 
     ao(); 
    return 0;
}
