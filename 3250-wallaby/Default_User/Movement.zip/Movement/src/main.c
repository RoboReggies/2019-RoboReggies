#include <kipr/botball.h>

int main ()
{
    // Drive forward at 80%
    motor(0,-80);
    motor(2,-80);
    
    // Wait for 2 seconds
    msleep(2000);
    
    // Stop motors
    ao();
    
    // End program
    return 0;
}
