#include <kipr/botball.h>

int main()
{

    
int leftwheel[4] = {10, 5, 20, 0};

int rightwheel[4] = {10, 0, 20, 5};

int Count=0;
while (count < 4)
{
//mrp (75,leftwheel[4];
//mrp(75,rightwheel[4];
Count++
}
