#include <kipr/botball.h>

int main ()
{
    while (analog (0 == 0)
           {
               if (analog(0) < 1800)
               {
                   motor(0,-80);
                   motor(2,-80);
               }
               else
               {
                   
                   if (analog(0) > 2600)
                   {
                       motor(0,75);
                       motor(2,75);
                   }
                   else // sensor value is 1800-2600
                   {
                       ao();
                   }
               }
           } //end of loop
           
           ao();
           return 0;
           }
           }