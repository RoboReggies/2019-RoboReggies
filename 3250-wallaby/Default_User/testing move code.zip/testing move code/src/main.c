#include <kipr/botball.h>

int main()
{
    int intleftmotorport = 2;
    int intrightmotorport = 0;
    //printf("left wheel");
    int leftwheel[4] = {100, 1000, 200, 0};
    //printf("right wheel");
    int rightwheel[4] = {100, 0, 200, 50};
    int count=0;
    while(count<4)
    	{ 
			printf("The answer to counter is %d ,left is %d ,right %d\n",count,Leftwheel[count],Rightwheel[count]);
			motor(intleftmotorport, leftwheel[count]);
			motor(intrightmotorport, rightwheel[count]);
        	msleep(1000);
        	count++;
	    }
    msleep(5000);
	return 0;
}