#include <kipr/botball.h>

int main()
{
int left = 2;
int right = 0;
      
int leftwheel[4] = {100, 50, 200, 0};
int rightwheel[4] = {100, 0, 200, 50};
int count=0;
    while(count<4)
    { 
//printf("Drive and turn\n");
//motor(left, leftwheel[count]);
//motor(right, rightwheel[count]);
//msleep(1000);

        move_relative_position(left,500,leftwheel[count]);
        move_relative_position(right,500,rightwheel[count]);
        count++;
        while(get_motor_done(0) && get_motor_done(2))
        {
            msleep(5);
}

return 0;
}