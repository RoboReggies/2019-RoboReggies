#include <kipr/botball.h>


void turn(int angle, int dir)
{
    switch (dir)
    {
        default:
            move(dir);
            msleep(angle*6.69 );
            move(0);
            break;
    }
}


void claw(int clawdir)
{
	switch (clawdir)
{
        case 0:
            motor(2, 0);
            break;
	  case 1:
			motor(2, 100);
            break;
	  case 2:
			motor(2, -100);
            break;
	  default:
			motor(2, 0);
			printf("%d", clawdir);
            break;
}
}
/*this is a function for moving the robot*/void move(int botdir)
{
    switch (botdir)
    {
        /*case for off*/case 0: 
            motor(0, 0);
            motor(1, 0);
            break;
       /*case for forward*/case 1: 
            motor(0, 100);
            motor(1, -100);
            break;
        /*case for Backwards*/case 2: 
            motor(0, -100);
            motor(1, 100);
            break;
        /*case for left*/case 3: 
            motor(0, -100);
            motor(1, -100);
            break;
       /*case for right*/ case 4: 
            motor(0, 100);
            motor(1, 100);
            break;
    }
}

int iOff=0;
int iFw=1;
int iBw=2;
int iL=3;
int iR=4;

int main()
{
    wait_for_light(0);
    int time=0;
        if (time<=0)
    {
        enable_servo(0);
        set_servo_position(0, 171);
        move(iFw);
        claw(iFw);
        msleep(3000);
        move(iBw);
        claw(iBw);
        msleep(3000);
            
        }
}

