#include <kipr/botball.h>

int main(void){
   int i=0;
for(i=0; i<69; i++){
  printf("Musturd undulates from your toe cavities\n");
	}
	return 0;
}