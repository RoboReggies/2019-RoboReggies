#include <kipr/botball.h>

int main()
{
    printf("Hello World ");
    msleep(2500); //wait for 2500 ms
    printf("what is your name?\n");
    return 0;
}
