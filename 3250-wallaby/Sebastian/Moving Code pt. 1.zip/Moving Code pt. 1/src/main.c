#include <kipr/botball.h>
void get_bot_guy(int plushie, int intSpeed); //created function to get botguy
int main()
{
    int LeftMotorPort =3;  //intLeftMotorPort
    int RightMotorPort =0;
    int Speed = 1500; // max speed for the robot, 500 min
    int LeftWheel[] = {1250, 1500, 7500, 0, 3000,  -3000, 2000, 4000, 0, 1000,  -2500, 2000, 2000, 2000, 1500};
    //turning of the wheel and distances
    int RightWheel[] ={1250, 0, 7500, 2000, 3000,  -3000, 0, 4000, 2000, 1000,  -2500, 0, 2000, 0, 1500};
    int count=0;
    int intCube = 0;
    int intBotGuy = 1;
    
    wait_for_light(0);
    shut_down_in(115);
    while(count<5) //First 5 moves
    {
        printf("The answer to counter is %d, left is %d, right %d\n", count,LeftWheel[count], RightWheel[count]);
        move_relative_position(LeftMotorPort, Speed, LeftWheel[count]); //move to the distances listed above
        move_relative_position(RightMotorPort, Speed, RightWheel[count]);
        bmd(LeftMotorPort);
        bmd(RightMotorPort);
        count++;
        
    }
    
    
    
    
   // msleep(2500);
    printf("Get BotGuy\n");
    enable_servos(); //tunring servos on
    set_servo_position( 1, 1692); //starting arm angle
    set_servo_position( 2, 1515); //startinge claw angle
    //msleep(2000);
    
    get_bot_guy(intCube, Speed);
    
    while(count<10) //Second 5 moves drops the 
        
    {
        printf("The answer to counter is %d, left is %d, right %d\n", count,LeftWheel[count], RightWheel[count]);
        move_relative_position(LeftMotorPort, Speed, LeftWheel[count]);
        move_relative_position(RightMotorPort, Speed, RightWheel[count]);
        bmd(LeftMotorPort);
        bmd(RightMotorPort);
        count++;
    }
    msleep(2500);
    printf("Drop BotGuy/n");
    enable_servos(); // turns on servos
    set_servo_position(2, 1239); //opens claw to drop botguy
    disable_servos();
    
    while(count < 15)
    {
        printf("The answer to counter is %d, left is %d, right %d\n", count,LeftWheel[count], RightWheel[count]);
        move_relative_position(LeftMotorPort, Speed, LeftWheel[count]);
        move_relative_position(RightMotorPort, Speed, RightWheel[count]);
        bmd(LeftMotorPort);
        bmd(RightMotorPort);
        count++;
    }
    return 0;
}
void get_bot_guy(int plushie, int intSpeed) // get botguy function data and what it does
{
    int intCount = 1;
    int intClose = 0;
    int intFar = 0;
    int intSlow = 0;
    int intGrip = 0;
  //  int intSpeed = 1500;
    int intHalfSpeed = 0;
    int intCloseClaw = 548; //Cube Close value
    int intArmUp = 900; //arm lift up angle
    msleep(1000);
  
    
    intHalfSpeed = intSpeed/2;
    if (plushie == 1)
    {
        intCloseClaw = 265; //botguy close value
           
    }
    
    printf("Going fast!\n");
    
    clear_motor_position_counter(0);
    clear_motor_position_counter(3);
    motor(0, intSpeed);
    motor(3, intSpeed);
    
    while (intCount)
        {
            intClose = analog(2);
            intFar= analog(1);
            printf("far is %d, close %d, intSlow %d, Grip %d \n",intFar, intClose, intSlow, intGrip);
            
            if (intFar > 2500)
            {
                intSlow = 1;
                    printf("Going to slow down\n");
                    motor(0, intHalfSpeed);
                    motor(3, intHalfSpeed);
            }
            if (intClose < 200)
            {
                intGrip = 1;
                intCount= 0;
                ao();
                
              	set_servo_position( 2, intCloseClaw);
                msleep(500);
                printf("Arm lift\n");
                set_servo_position( 1, intArmUp);
                msleep(500);
                printf("Done lifting!\n");
                
            }
        }
    printf("END - far is %d, close %d, intSlow %d, Grip %d \n",intFar, intClose, intSlow, intGrip);
    //add while loop backup to starting position
    while(get_motor_position_counter(0) && get_motor_position_counter(3) > 0)
    {
         motor(0, -intSpeed);
         motor(3, -intSpeed);
    }
    ao();
}
