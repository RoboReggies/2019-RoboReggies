#include <kipr/botball.h>
void get_bot_guy(int plushie); //created function to get botguy
int main()
{
    int intCube = 0;
    int intBotGuy = 1;
    enable_servos(); //before wait for light
    set_servo_position( 1, 1692); //starting arm angle
    set_servo_position( 2, 1515); //startinge claw angle
    msleep(2000);
    
    
    get_bot_guy(intBotGuy); // get botguy function being used
    //get_bot_guy(intCube); // cube function being used
    
    
    
   // disable_servos();
    //msleep(2000);
    return 0;
}
void get_bot_guy(int plushie) // get botguy function data and what it does
{
    int intCount = 1;
    int intClose = 0;
    int intFar = 0;
    int intSlow = 0;
    int intGrip = 0;
    int intCloseClaw = 548; //Cube Close value
    int intArmUp = 1000; //arm lift up angle
    msleep(1000);
        
    if (plushie == 1)
    {
        intCloseClaw = 265; //botguy close value
           
    }
    while (intCount)
        {
            intClose = analog(2);
            intFar= analog(1);
            printf("far is %d, close %d, intSlow %d, Grip %d \n",intFar, intClose, intSlow, intGrip);
            
            if (intFar > 2500)
            {
                intSlow = 1;
            }
            if (intClose < 200)
            {
                intGrip = 1;
                intCount= 0;
                                   
              	set_servo_position( 2, intCloseClaw);
                msleep(500);
                printf("Arm lift\n");
                set_servo_position( 1, intArmUp);
                msleep(500);
                printf("Done lifting!\n");
                
            }
        }
    printf("END - far is %d, close %d, intSlow %d, Grip %d \n",intFar, intClose, intSlow, intGrip);
}

