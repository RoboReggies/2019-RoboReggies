#include <kipr/botball.h>
void get_bot_guy(int plushie, int intSpeed); //created function to get botguy
int main()
{
    int intCube = 0;
    int intBotGuy = 1;
    enable_servos(); //before wait for light
    set_servo_position( 1, 1692); //starting arm angle
    set_servo_position( 2, 1515); //startinge claw angle
    msleep(2000);
    
    
    get_bot_guy(intBotGuy, 1500 ); // get botguy function being used
    //get_bot_guy(intCube); // cube function being used
    
    
    
   // disable_servos();
    //msleep(2000);
    return 0;
}
void get_bot_guy(int plushie, int intSpeed) // get botguy function data and what it does
{
    int intCount = 1;
    int intClose = 0;
    int intFar = 0;
    int intSlow = 0;
    int intGrip = 0;
  //  int intSpeed = 1500;
    int intHalfSpeed = 0;
    int intCloseClaw = 548; //Cube Close value
    int intArmUp = 1000; //arm lift up angle
    msleep(1000);
  
    
    intHalfSpeed = intSpeed/2;
    if (plushie == 1)
    {
        intCloseClaw = 265; //botguy close value
           
    }
    
    printf("Going fast!\n");
    
    clear_motor_position_counter(0);
    clear_motor_position_counter(3);
    motor(0, intSpeed);
    motor(3, intSpeed);
    
    while (intCount)
        {
            intClose = analog(2);
            intFar= analog(1);
            printf("far is %d, close %d, intSlow %d, Grip %d \n",intFar, intClose, intSlow, intGrip);
            
            if (intFar > 2500)
            {
                intSlow = 1;
                    printf("Going to slow down\n");
                    motor(0, intHalfSpeed);
                    motor(3, intHalfSpeed);
            }
            if (intClose < 200)
            {
                intGrip = 1;
                intCount= 0;
                ao();
                
              	set_servo_position( 2, intCloseClaw);
                msleep(500);
                printf("Arm lift\n");
                set_servo_position( 1, intArmUp);
                msleep(500);
                printf("Done lifting!\n");
                
            }
        }
    printf("END - far is %d, close %d, intSlow %d, Grip %d \n",intFar, intClose, intSlow, intGrip);
    //add while loop backup to starting position
    while(get_motor_position_counter(0) && get_motor_position_counter(3) > 0)
    {
         motor(0, -intSpeed);
         motor(3, -intSpeed);
    }
}

