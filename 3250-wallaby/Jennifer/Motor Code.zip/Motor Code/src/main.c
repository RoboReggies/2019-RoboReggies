#include <kipr/botball.h>

motor(0,100)
    // Turns on motor port #0 at 100% power.
    // Select any power between -100% and 100%
    
msleep(# milliseconds);
	//Wait for the specified amount of time

ao();
	//Turn off all of the motors
