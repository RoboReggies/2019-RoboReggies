#include <kipr/botball.h>

int main()
{
    wait_for_light(0);
    shut_down_in(115);
    int Speed = 1500;
    while(digital(0) == 0) //when bumper is touched the bot stops moving
    {
         motor(0, Speed);
         motor(3, Speed);
    }
    return 0;
}
