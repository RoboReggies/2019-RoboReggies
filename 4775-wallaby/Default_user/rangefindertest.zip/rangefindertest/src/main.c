#include <kipr/botball.h>

int main()
{
 
    
    while(1)
        {
        if (analog(3) <= 1300)        
        {    
            printf("Not Yet\n");
            
            int analog (analog(3)
            
        }
        if (analog(3) >= 1300)
        {
    printf("I work\n");
            
    }        
    }
    return 0;
}
