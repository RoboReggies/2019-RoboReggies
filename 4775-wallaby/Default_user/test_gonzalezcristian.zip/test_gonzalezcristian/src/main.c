#include <kipr/botball.h>

int main()
{
    void enable_servo(0,1);
   void enable_servo(0,1);
   void set_servo_position(0,100);
    return(0);
}
