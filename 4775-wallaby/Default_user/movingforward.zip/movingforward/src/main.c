#include <kipr/botball.h>

int main()
{
   shut_down_in(15);
    motor(0,100);
    motor(1,100);
    msleep(15000);
        ao();
return 0;
}
