#include <kipr/botball.h>

int LineFollow2Sensor(int intSpeed, int intDistance, int intLeftSensor, int intLeftWheel, int intRightSensor, int intRightWheel);
    
int main()
{
    int intDoneDriving = 1;
    printf("Hello World\n");
    
    intDoneDriving = LineFollow2Sensor(50,75,0,0,1,1);
    
    printf("intDoneDriving = %d\n", intDoneDriving);
    
    return 0;
}

int LineFollow2Sensor(int intSpeed, int intDistance, int intLeftSensor, int intLeftWheel, int intRightSensor, int intRightWheel)
{
	int intDone = 0;
    printf("intSpeed = %d\n", intSpeed);
    printf("intDistance = %d\n", intDistance);
    printf("intLeftSensor = %d\n", intLeftSensor);
    printf("intLeftWheel = %d\n", intLeftWheel);
    printf("intRightSensor = %d\n", intRightSensor);
    printf("intRightWheel = %d\n", intRightWheel);
    
    return intDone;
}