#include <kipr/botball.h>

int main()
{
    motor(0, 100);
    motor(1, 100);
    msleep(1000);
    ao();
    //this friikken works
    return 0;
}
