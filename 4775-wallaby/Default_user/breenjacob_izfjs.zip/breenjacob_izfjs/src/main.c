#include <kipr/botball.h>
 if (analog(0) < ibright)
       {
           motor(0, ispeed);
           motor(1, islowspeed);
       }
        if (analog(0) < ibright && analog(2) > ibright)
        {
            motor(0, ispeed);
            motor(1, ispeed);
        }
        if (analog(0) > ibright && analog(1) > ibright)
        {
            motor(0, islowspeed);
            motor(1, ispeed/2);
        }
        if (analog(1) > ibright && analog(2) < ibright)
        {
            motor(0, ispeed/2);
            motor(1, islowspeed);
        }
        if (analog(2) < ibright && analog(1) < ibright)
        {
            motor(0, islowspeed);
            motor(1, ibright/2);
        }
        if (analog(0) > ibright && analog (2) < ibright)
        {
            motor(0, islowspeed);
            motor(1, ispeed/2);
        }
        if (analog(0) > ibright && analog(2) > ibright)
        {
            motor(0, islowspeed);
            motor(1, ispeed/2);
        }
