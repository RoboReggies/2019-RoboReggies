#include <kipr/botball.h>

int LineFollow2Sensor(int intSpeed, int intDistance, int intBright, int intLeftSensor, int intLeftWheel, int intRightSensor, int intRightWheel);
    
int main()
{ 
    int intDoneDriving = 1;
    int intBright = 500;
    //int intExit =1;
    printf("Hello World\n");
    printf("Left = %d\n", analog(0));
    printf("right = %d\n", analog(1));
    printf("an0 = %d\n",(analog(0) > intBright));
    printf("an1 = %d\n",(analog(1) > intBright));
    
    //msleep(50);
   /* 
    while (intExit)
    {
       motor(0, 50);
       motor(1, 50);
        console_clear();
        if((analog(0) > intBright) && (analog(1) > intBright))
        {
            intExit = 0;
            printf("EXITING\n");
            printf("Left = %d\n", analog(0));
       		printf("right = %d\n", analog(1)); 
           //msleep(1000);
        }
      
                                    
    }
   printf("done Left = %d\n", analog(0));
   printf("done right = %d\n", analog(1));     
       */ 
    intDoneDriving = LineFollow2Sensor(50,5000,300,0,0,1,1);
    
    printf("intDoneDriving = %d\n", intDoneDriving);
    
    return 0;
}

int LineFollow2Sensor(int intSpeed, int intDistance, int intBright, int intLeftSensor, int intLeftWheel, int intRightSensor, int intRightWheel)
{
	int intDriving = 1;
    int intDirection = 1;
    
    //printf("intSpeed = %d\n", intSpeed);
   // printf("intDistance = %d\n", intDistance);
    //printf("intLeftSensor = %d\n", intLeftSensor);
    //printf("intLeftWheel = %d\n", intLeftWheel);
    //printf("intRightSensor = %d\n", intRightSensor);
   // printf("intRightWheel = %d\n", intRightWheel);
    
    
    
    //void clear_motor_position_counter(int motor_nbr)
    //int get_motor_position_counter(int m);
    
    clear_motor_position_counter(intLeftWheel);
    clear_motor_position_counter(intRightWheel);
    //printf("LeftWheel = %d\n", get_motor_position_counter(intLeftWheel));
    //printf("RightWheel = %d\n", get_motor_position_counter(intRightWheel));
    //printf("Average = %d\n", (get_motor_position_counter(intLeftWheel) + get_motor_position_counter(intRightWheel)/2));
    //msleep(1000);
        
    while (intDriving){
   console_clear();
        
        
    if (analog(intRightSensor) > intBright) {
            intDirection = 1;
       }

    else{
           intDirection = 0;
       }    
    if (analog(intLeftSensor) > intBright) {
            intDirection = intDirection + 2;
       }
       printf("Direction = %d\n", intDirection);
       msleep(250);
    
    
     switch(intDirection){
            case 0:
                motor(intLeftWheel, intSpeed);
                motor(intRightWheel, intSpeed/2);
                printf("\nTurn Right\n");
                break;
            case 1:
                motor(intLeftWheel, intSpeed);
                motor(intRightWheel, intSpeed);
                printf("\nFowards\n");
                break;
            case 2:
                motor(intLeftWheel, intSpeed/2);
                motor(intRightWheel, intSpeed);
                printf("\nTurn Left\n");
                break;
            case 3:
                motor(intLeftWheel, intSpeed/2);
                motor(intRightWheel, intSpeed);
                printf("\nTurn Left\n");
                break;
        }
       printf("LeftWheel = %d\n", get_motor_position_counter(intLeftWheel));
       printf("RightWheel = %d\n", get_motor_position_counter(intRightWheel));
       printf("Average = %d\n", ((get_motor_position_counter(intLeftWheel) + get_motor_position_counter(intRightWheel))/2));
        if (((get_motor_position_counter(intLeftWheel) + get_motor_position_counter(intRightWheel))/2) <  intDistance)  
             {
        		intDriving = 1;
             }
             else
             {
                 intDriving = 0;
             }
    }
    return intDriving = 1;
}