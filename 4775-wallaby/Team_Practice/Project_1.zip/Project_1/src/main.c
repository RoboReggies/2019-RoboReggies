#include <kipr/botball.h>

int main()
{
    enable_servo (0);
        set_servo_position (0,100)//hey guys this command is for set the servo in place
        motor (
        
    printf("Move the\n");
    return 0;
}
