#include <kipr/botball.h>

int main()
{
    motor(0, 100);
    printf("motor move boi\n");
    enable_servo(0);
    printf("enable servo boi\n");
    set_servo_position(0, 1600);
    printf("servo movey boi\n");
    msleep(10000);
    return 0;
}
