#include <kipr/botball.h>

int main()
{
    // printf("Hello World\n");
     
    motor(0,-10000);
   	motor(1,-10000);
    msleep(1000);
    return 0;
    //move_at_velocity(0, 2500000);
    //move_at_velocity(1, 2500000);
}

//{
   // enable_motors(0,1);
    
   // mav (0, 1500);
    
   // motor_power (0,100);
    
   // mtp (0, 1500);
       
