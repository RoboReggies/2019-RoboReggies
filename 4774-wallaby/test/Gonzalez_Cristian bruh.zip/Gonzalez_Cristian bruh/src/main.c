#include <kipr/botball.h>

int main()
{
    printf("Let's go Reggies\n");
    
   
    printf ("GENTE DE ZONA!/n");
    
    printf ("victory royle but it is said on a robot");
    return 0;
}
