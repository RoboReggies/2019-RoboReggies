#include <kipr/botball.h>

int main()
{
    create_connect(); //connects
    //printf("I'm connected");
    while (get_create_rbump() || get_create_lbump() == 0) //if right or left bump not pressed it will keep driving
    {
        //printf("I'm in the loop");
        create_drive_direct(100,100); //driving at 100 mm per second
    }
    
    //printf("I'm out of the loop and shutting down");
    create_stop(); //stops motors
    create_disconnect(); //disconnects
    return 0;
}
