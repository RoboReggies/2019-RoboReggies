#include <kipr/botball.h>

int main()
{
    create_connect();
    //shut_down_in(30);
    //printf("Hello World\n");
    
    while (1)
    {   
    console_clear();    
    printf("Lcliff = %d\n",get_create_lcliff());
    printf("LcliffAMT = %d\n",get_create_lcliff_amt());
    printf("LcFliff = %d\n",get_create_lfcliff());
    printf("LcFliffAMT = %d\n",get_create_lfcliff_amt());       
    printf("Rcliff = %d\n",get_create_rcliff());
    printf("RcliffAMT = %d\n",get_create_rcliff_amt());
    printf("RcFliff = %d\n",get_create_rfcliff());
    printf("RcFliffAMT = %d",get_create_rfcliff_amt());
    msleep(250);
    }
    
    create_stop();
	create_disconnect();
    return 0;
}

