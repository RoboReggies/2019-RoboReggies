#include <kipr/botball.h>
#include <math.h>

void cDrive(int cSpeed, int cSec);
void cSpin(int cSpeed, int cSec);

int main()
{
    wait_for_light(0);
    create_connect();
    shut_down_in(118);
    
    //spin towards firepole
    while (get_create_total_angle() < 179)
    {
        create_drive_direct(-100, 100);
    }
    
    //drives forward for 4 second to get out of box
    //cDrive(-100, 6.5);
    create_drive_direct(-100,-100);
    msleep(6200);
    
    //turn to face firepole
    /*ile (get_create_total_angle() < 90);
    {
        create_drive_direct(-100, 100);
        printf("going to face the pole");
    }
    */
    printf("facing the pole");
    
    //drive towards firepole
    cDrive(-100, 1);
    
    //turns 90 degrees
     /*while (get_create_total_angle() < 95)
    {
        create_drive_direct(-100, 100);
    }
    
    //drives towards the firefighter pole
    cDrive(-100, 6);
    
    while ((get_create_rbump() == 0) || (get_create_lbump() == 0))
    {
        create_drive_direct(-100,-100);
    }
    create_drive_direct(100,100);
    msleep(100);
    */
    
    //spin 6 times
    while (get_create_total_angle() < 2520)
    {
        printf("Spinning\n");
        create_drive_direct(-100, 100);
    }
    
    //wait a sec
    msleep(5000);
    
    //drive(-100,5);
    
    
    create_disconnect();
    return 0;
}

void cDrive(int cSpeed, int cSec)
{
    create_drive_straight(cSpeed);
    int cMS = cSec * 1000;
    msleep(cMS);
}

void cSpin(int cSpeed, int cSec)
{
    create_drive_direct(cSpeed, -cSpeed);
    int cMS = cSec * 1000;
    msleep(cMS);
}