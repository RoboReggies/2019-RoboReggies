#include <kipr/botball.h>

int main()

    
 { enable_servos(1);//turns servo ports on 
set_servo_position(0,100);//moves servo in specified part to a set position }
motor(0,70);//turns on motor at % power specified
   