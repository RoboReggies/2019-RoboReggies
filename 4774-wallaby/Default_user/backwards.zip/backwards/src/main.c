#include <kipr/botball.h>

int main()
{
    //wait_for_light(0);
    create_connect();
    shut_down_in(118);
    
    while ((get_create_rbump() == 0) || (get_create_lbump() == 0))
    {
        create_drive_direct(200,200);
    }
    create_drive_direct(-100,-100);
    msleep(500);
    
    while (get_create_total_angle() < 4320)
    {
        printf("Spinning\n");
        create_drive_direct(-100, 100);
    }
    
    
    
    create_disconnect();
    
    printf("Hello World\n");
    return 0;
}
