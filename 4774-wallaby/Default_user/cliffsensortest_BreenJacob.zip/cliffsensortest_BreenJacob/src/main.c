#include <kipr/botball.h>



int main()
{
    create_connect();
    shut_down_in(119);
    
    //drives out of the DRZ
    /*printf("Im driving towards the firefighter box\n");
    set_create_distance(0);
    while (get_create_distance() < 800)
    {
        create_drive_direct(100,100);
        
    }
    printf("I am at the box\n");
    
    create_spin_CW(100);*/
    
    printf("I will drive untill I see black line");
    //Drive towards the black line near firefighter pole
    if (get_create_rcliff_amt() < 700){
            create_drive_direct(0,0);
        }
    else
        {
            
            create_drive_direct(100,100);
        }
    printf("I found black line and will stop now");
    msleep(5000);
    
    
    //drive forward a little bit and turn at a angle
    
    /**/
    
	create_disconnect();
    return 0;
}
