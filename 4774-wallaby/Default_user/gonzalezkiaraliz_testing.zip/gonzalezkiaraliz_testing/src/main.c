#include <kipr/botball.h>

int main()
{
    create_connect();
    int i=0;
    
    if (i>= 0) {
       set_create_distance(10);
	create_drive_direct(100, 100);
    printf("Hello World\n");
    msleep(15000);
        i++;
    }


}
