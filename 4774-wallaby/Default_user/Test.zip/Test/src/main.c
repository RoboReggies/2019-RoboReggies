#include <kipr/botball.h>

int main()
{
    printf("Hello World\n");
    
    //Connects to create, sets up to start when light is turned on, shuts down in 1 second
    create_connect();
    wait_for_light(0);
    shut_down_in(119);
    
    //create speed
    create_drive_direct(100,100);
    
    //create distance
    //set_create_distance(30);
    
    msleep(4000);
    
    printf("Hello World after\n");
    
    //stops the create, and disconnects it
    create_stop();
    create_disconnect();
    
    return 0;
}
