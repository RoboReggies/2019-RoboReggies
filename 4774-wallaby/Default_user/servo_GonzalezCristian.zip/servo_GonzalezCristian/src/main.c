#include <kipr/botball.h>

int main()
{
    motor(0,100);
    return 0;
}
