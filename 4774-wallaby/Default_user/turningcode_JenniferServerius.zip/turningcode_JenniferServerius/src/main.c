#include <kipr/botball.h>
#include <math.h>
void cTurn(int degs, int speed, int cw);
int main()
{
    create_connect();
    printf("Connected\n");
    msleep(1000);
    printf("going into cTurn function\n");
    cTurn(45, 100, 0);
    msleep(1000);
    printf("Disconnecting now\n");
    msleep(1000);
    create_disconnect();
    return 0;
}
void cTurn(int cDegs, int cSpeed, int cCw)
        {
    cSpeed=100;
    		set_create_total_angle(0);
    		if (cCw == 0)
            {
                printf("In if statement\n");
                
                while (get_create_total_angle() <= cDegs)
                {
                    printf("Going Clockwise\n");
                    create_drive_direct(cSpeed,-cSpeed);
                    msleep(1000);
                }
                create_drive_direct(0, 0);
            }
    		else
            {
                while (get_create_total_angle() <= cDegs)
                {
                    printf("Going Counter Clockwise\n");
                    create_drive_direct(-cSpeed, cSpeed);
                }
                create_drive_direct(0, 0);
            }
        }
