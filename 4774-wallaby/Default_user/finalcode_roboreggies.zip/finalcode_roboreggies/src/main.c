#include <kipr/botball.h>
#include <math.h>

void cDrive(int cSpeed, int cSec);
void cSpin(int cSpeed, int cSec, int cCW);
void cDegTurn(int cDeg, int cSpeed, int cRot);

int main()
{
    //wait_for_light(0);
    create_connect();
    shut_down_in(20);
    
    printf("Starting Robot\n");
    
    cDegTurn(1080, 50, 0);
    
   /* //turn slightly
    set_create_total_angle(0);
    while (get_create_total_angle() > 45)
    {
        create_drive_direct(100, -100);
    } */
    
    //drives forward for 4 seconds to get out of box
    //cDrive(100, 6); //WORKS
    
    //spins ccw 5 times
    // cSpin(100, 5, 1); //WORKS
    
    //turn
    /*set_create_total_angle(0);
    while (get_create_total_angle() < 45)
    {
        create_drive_direct(-100, 100);
    } */
    
    //cDrive(100, 5);
    
    //cSpin(100,1,1);
    
    //printf("turning\n");
    //cDegTurn(90, 100, 1);
    
    
    
    create_disconnect();
    return 0;
}


void cDrive(int cSpeed, int cSec)
{
    create_drive_straight(cSpeed);
    int cMS = cSec * 1000;
    msleep(cMS);
}

void cSpin(int cSpeed, int cSec, int cCW)
{
    if (cCW == 0)
    {
        printf("Going Clockwise\n");
        create_drive_direct(cSpeed, -cSpeed);
        int cMS = cSec * 1000;
        msleep(cMS);
    }
    else
    {
        printf("Going Counter Clockwise\n");
        create_drive_direct(-cSpeed, cSpeed);
        int cMS = cSec * 1000;
        msleep(cMS);
    }
}

void cDegTurn(int cDeg, int cSpeed, int cRot)
{
    if(cRot == 0)
    {
        set_create_total_angle(0);
        printf("Total_Angel B4 = %d\n", get_create_total_angle());
    	while (get_create_total_angle() < cDeg)
    	{
        	create_drive_direct(-cSpeed,cSpeed);
        }
        printf("Total_Angel AFT = %d\n", get_create_total_angle());
        //cRot ++;
    }
    else
    {
        if(cRot == 1)
        {
        	set_create_total_angle(0);
    		while (get_create_total_angle() < cDeg)
    		{
        		create_drive_direct(cSpeed,-cSpeed);
    		}
        }
        else 
        {
            create_drive_direct(0,0);
        }
    }
}
        
        