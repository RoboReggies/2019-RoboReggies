#include <kipr/botball.h>

int main()
{
    create_connect();
    shut_down_in(119);
    
    set_create_distance(10);
    while (get_create_distance() < 700)
    {
        create_drive_direct(200,200);
        
    }
    printf("I am at the box\n");
    
    int spinT = 10;
    while (spinT < 30)
    {
        create_spin_CW(100);
        printf("I've spinned\n");
        msleep(1000);
        spinT ++;
    }
    
    msleep(1000);
    create_disconnect();
    return 0;
}
